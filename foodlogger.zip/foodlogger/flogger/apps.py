from django.apps import AppConfig


class FloggerConfig(AppConfig):
    name = 'flogger'
