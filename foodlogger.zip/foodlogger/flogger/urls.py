from django.urls import path
from . import views

app_name='flogger'

urlpatterns = [

    path('', views.index, name='index'),
    path('add_meal', views.add_meal, name='add_meal'),
    path('browse_meals', views.add_meal, name='browse_meals'),
    path('edit_foods', views.edit_foods, name='edit_foods'),
    path('food/<int:pk>', views.FoodUpdate.as_view(), name='update_food')

]