from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.views.generic.edit import UpdateView
from .models import Meal, Food
from .forms import MealForm

# Create your views here.
def index(request):

    meals=Meal.objects.filter(user=request.user).order_by('-date')[:10]
    return render(request, 'flogger/index.html', {'meals': meals})

def add_meal(request):
    if request.method == 'POST':
        form = MealForm(request.POST)
        if form.is_valid():
            meal = form.save(commit=False)
            meal.user = request.user
            meal.save()
            return HttpResponseRedirect(reverse('flogger:index'))
    else:
        form = MealForm()
    return render(request, 'flogger/add_meal.html', {'form': form})

def get_pages_around(i_current, i_max, i_range):
    i_start=max(i_current-i_range, 1)
    i_end=min(i_current+i_range, i_max)
    return range(i_start, i_end+1)

def edit_foods(request):
    foods = Food.objects.all().order_by('pk')
    page = request.GET.get('page', 1)

    paginator = Paginator(foods, 2)

    try:
        foods_short = paginator.page(page)
    except PageNotAnInteger:
        foods_short = paginator.page(1)
    except EmptyPage:
        foods_short = paginator.page(paginator.num_pages)

    return render(request, 'flogger/foods_list.html',
                  {'foods': foods_short,
                   'page_range': get_pages_around(foods_short.number, paginator.num_pages, 3)})

class FoodUpdate(UpdateView):
    model = Food
    fields = ['name', 'energy', 'amount', 'unit', 'source', 'protein', 'carbs', "fat"]
    success_url = reverse_lazy('flogger:edit_foods')